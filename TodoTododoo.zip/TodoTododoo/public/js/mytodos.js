// DOMContentLoaded : html이 완전히 로딩됐을 때 실행되는 이벤트
// addEventListener : 어떤 이벤트가 발생하면 실행할 함수를 등록하는 기능

import { deleteTodo, toggleDone } from "../../controller/todoController.mjs";

// => 전체 코드를 웹 페이지가 완전히 로드된 이후에 실행하겠다는 뜻
document.addEventListener("DOMContentLoaded", () => {
  // 각 html 요소의 id로 input/form/ul 등을  가져오는 코드
  const todoList = document.getElementById("todoList");
  const todoForm = document.getElementById("todoFrom");
  const titleInput = document.getElementById("title");
  const contentInput = document.getElementById("content");

  // localStorage는 브라우저에 저장된 데이터 중 token 값을 불러옴
  // 로그인 시 저장된 사용자 인증 토큰을 서버에 보낼 때 사용
  const token = localStorage.getItem("token");

  // 서버에서 데이터를 받아오기 위해 비동기 함수로 선언 (할 일 목록)
  async function loadTodos() {
    try {
      // todos/me 주소로 fetch 요청을 보냄.
      // 헤더에 인증 토큰을 포함해서 내 할 일만 가져오도록 설정
      const res = await fetch(`/todos/me`, {
        headers: {
          Authorication: `Bearer ${token}`,
        },
      });
      // 응답 데이터를 json으로 바꾸고, renderTodos 함수로 넘겨서 화면에 그림
      // renderTodos 함수는 아래에 만듦
      const todos = await res.json();
      renderTodos(todos);
    } catch (err) {
      alert("할 일이 없는뎁쇼");
    }
  }

  // 할 일 화면에 렌더링
  function renderTodos(todos) {
    todoList.innerHTML = ""; // 기존 할 일 리스트를 비움(초기화)
    // 서버에서 받아온 todos 배열을 화면에 하나씩 돌면서 li 로 만드는 반복문
    todos.forEach((todo) => {
      // li 항목을 하나 동적으로 생성하고, 클래스 추가
      const li = document.createElement("li");
      li.classList.add("todo-item");

      // 체크박스 만들기
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      // done이 1이면 체크된 상태로
      checkbox.checked = todo.done === 1;
      // 체크박스를 누르면 toggleDone 함수로 완료 여부를 서버에 반영
      checkbox.addEventListener("change", () =>
        toggleDone(todo.id, checkbox.checked)
      );
      const title = document.createElement("strong");
      title.textContent = todo.title; // textContent : html태그를 무시하고 텍스트만 읽음

      const content = document.createElement("p");
      content.textContent = todo.content;

      if (todo.done === 1) {
        title.style.textDecoration = "line-through";
        content.style.textDecoration = "line-through";
      }

      const editBtn = document.createElement("button");
      editBtn.textContent = "수정";
      editBtn.addEventListener("click", () => editTodo(todo));

      const deleteBtn = document.createElement("button");
      deleteBtn.textContent = "삭제";
      deleteBtn.addEventListener("click", () => deleteTodo(todo.id));

      li.appendChild(checkbox);
      li.appendChild(title);
      li.appendChild(content);
      li.appendChild(editBtn);
      li.appendChild(deleteBtn);

      todoList.appendChild(li);
    });
  }

  // 할 일 등록
  todoFrom.addEventListener("submit", async (e) => {
    e.preventDefault();
    const title = titleInput.value.trim();
    const content = contentInput.value.trim();

    if (!title) {
      alert("제목을 입력하세요");
      return;
    }

    try {
      const res = await fetch(`/todos`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorication: `Bearer ${token}`,
        },
        body: JSON.stringify({ title, content }),
      });

      if (res.ok) {
        titleInput.value = "";
        contentInput.value = "";
        loadTodos();
      } else {
        const result = await res.json();
        alert(result.message || "등록 실패");
      }
    } catch (err) {
      alert("등록 중 오류 발생");
    }
  });

  // 완료 상태 토글
  async function toggleDone(id, done) {
    try {
      await fetch(`/todos${id}/done`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorication: `Bearer ${token}`,
        },
        body: JSON.stringify({ done: done ? 1 : 0 }),
      });
      loadTodos();
    } catch (err) {
      alert("완료 상태 변경 실패");
    }
  }

  // 삭제
  async function deleteTodo(id) {
    if (!confirm("정말 삭제하시겠습니까?")) return;
    try {
      await fetch(`/todos/${id}`, {
        method: "DELETE",
        headers: {
          Authorication: `Bearer ${token}`,
        },
      });
      loadTodos();
    } catch (err) {
      alert("삭제 실패");
    }
  }
  // 수정 (제목과 내용만 간단히 prompt로 처리)
  async function editTodo(todo) {
    const newTitle = prompt("새 제목:", todo.title);
    const newContent = prompt("새 내용:", todo.content);
    if (!newTitle) return;

    try {
      await fetch(`/todos/${todo.id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ title: newTitle, content: newContent }),
      });
      loadTodos();
    } catch (err) {
      alert("수정 실패");
    }
  }
  // 로그아웃
  window.logout = function () {
    localStorage.removeItem("token");
    location.href = "/login.html";
  };

  loadTodos(); // 초기 로딩
});
